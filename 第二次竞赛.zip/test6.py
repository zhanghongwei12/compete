from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
import numpy as np


def loadData(filename, dataCount):
    data = np.loadtxt(filename, dtype=str, delimiter=',')
    for col in range(data.shape[1]):
        valueCount = dataCount(filename, col)
        nan = list(valueCount.keys())[list(valueCount.values()).index(max(valueCount.values()))]
        dataCol = data[:, col]
        dataCol[dataCol == '?'] = nan
    data = np.core.defchararray.strip(data, '()').astype(int)
    return data



def dataCount(filename, col):
    data = np.loadtxt(filename, dtype=str, delimiter=',')
    valueCount = dict()
    for label in range(10):
        count = 0
        for value in data[:, col]:
            if str(label) == value:
                count += 1
        valueCount[label] = count

    return valueCount

def splitDataset(dataset, ratio):
    test_num = int(len(dataset) * ratio)
    train_set = dataset[: len(dataset)-test_num, :]
    test_set = dataset[len(dataset)-test_num :, :]
    X_train = train_set[:, :-1]
    y_train = train_set[:, -1]
    X_test = test_set[:, :-1]
    y_test = test_set[:, -1]

    return X_train, y_train, X_test, y_test




filename = 'train.csv'
dataset = loadData(filename, dataCount)
testset = loadData('test.csv',dataCount)


model1 = SelectKBest(chi2, k=6)
X_dataset = model1.fit_transform(dataset[:, :-1], dataset[:, -1])
print(model1.scores_)
new_dataset = np.concatenate((np.array(testset[:, 1]).reshape(len(testset), 1), np.array(testset[:, 2]).reshape(len(testset), 1)), axis=1)
new_dataset = np.concatenate((new_dataset, np.array(testset[:, 3]).reshape(len(testset), 1)), axis=1)
new_dataset = np.concatenate((new_dataset, np.array(testset[:, 4]).reshape(len(testset), 1)), axis=1)
new_dataset = np.concatenate((new_dataset, np.array(testset[:, 8]).reshape(len(testset), 1)), axis=1)
new_dataset = np.concatenate((new_dataset, np.array(testset[:, 9]).reshape(len(testset), 1)), axis=1)
print(new_dataset.shape)
X_test = X_dataset[-1000:, :]
y_test = dataset[-1000:, -1]
X_train = X_dataset[:-1000, :]
y_train = dataset[:-1000, -1]

from sklearn.neighbors import KNeighborsClassifier
for n_neighbors in range(1, 50):
    knn = KNeighborsClassifier(n_neighbors=n_neighbors)
    knn = knn.fit(X_train, y_train)
    predict = knn.predict(X_test)
    count = 0
    for i in range(len(predict)):
        if predict[i] == y_test[i]:
            count += 1
    print("K:{}, pre:{}".format(n_neighbors, count/len(predict)))
knn = KNeighborsClassifier(n_neighbors=45)
knn = knn.fit(X_dataset, dataset[:, -1])
predict = knn.predict(new_dataset)

np.savetxt('b.csv', predict)



